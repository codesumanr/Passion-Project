﻿
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace libraraydatabase.Models
{
    public class Member
    {
        [Key] // Primary key
        public int MemberId { get; set; }

        [Required] // Name is required
        [StringLength(100)] // Maximum length of 100 characters
        public string Name { get; set; }

        [Required] // EmailId is required
        [EmailAddress] // Validate email format
        public string EmailId { get; set; }

       
    }
}
