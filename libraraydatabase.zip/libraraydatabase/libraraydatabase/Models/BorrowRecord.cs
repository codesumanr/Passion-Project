﻿using librarydatabase.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Libraraydatabase.Models
{
    public class BorrowRecord
    {
        [Key] // Primary key
        public int BorrowRecordId { get; set; }

        [Required] // BookId is required
        [ForeignKey("Book")] // Foreign key relationship with Book
        public int BookId { get; set; }
        public virtual Book Book { get; set; } // Navigation property for Book



        [Required] // BorrowDate is required
        public DateTime BorrowDate { get; set; }

        [Required] // DueDate is required
        public DateTime DueDate { get; set; }

        public DateTime? ReturnDate { get; set; } // ReturnDate is optional (nullable)


    }
   

}