﻿
using librarydatabase.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace libraraydatabase.Models
{
    public class Fine
    {
        [Key] // Primary key
        public int FineId { get; set; }

        [Required] // BookId is required
        [ForeignKey("Book")] // Foreign key relationship with Book
        public int BookId { get; set; }
        public virtual Book Book { get; set; } // Navigation property for Book

        [Required] // MemberName is required
        [StringLength(100)] // Maximum length of 100 characters
        public string MemberName { get; set; }

        [Required] // DueDate is required
        public DateTime DueDate { get; set; }

        [Required] // DaysOverdue is required
        public int DaysOverdue { get; set; }

        // Computed property to calculate the fine amount
        public decimal FineAmount
        {
            get => DaysOverdue * 5; // Assuming a fine of $5 per day
            set { } // No setter needed
        }
    }
}
