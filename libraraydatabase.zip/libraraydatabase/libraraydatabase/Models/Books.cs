﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace librarydatabase.Models
{
    public class Book
    {
        [Key] // Primary key

        public int BookId { get; set; }

        [Required] // Title is required
        [StringLength(100)] // Maximum length of 100 characters
        public string Title { get; set; }

        [Required] // Category is required
        [StringLength(100)] // Maximum length of 100 characters
        public string Category { get; set; }

        [Required] // ISBN is required
        public int ISBN { get; set; }


        public class BookDto
        {
            public int BookId { get; set; }
            public string Title { get; set; }
            public string Category { get; set; }
            public int ISBN { get; set; }
            public bool IsAvailable { get; set; }
        }
        public class UpdateBookDto
        {
            [Key] // Primary key
            public int BookId { get; set; }

            [Required] // Title is required
            [StringLength(100)] // Maximum length of 100 characters
            public string Title { get; set; }

            [Required] // Category is required
            [StringLength(100)] // Maximum length of 100 characters
            public string Category { get; set; }

            [Required] // ISBN is required
            public int ISBN { get; set; }
        }
        public class AddBookDto
        {
            [Required] // Title is required
            [StringLength(100)] // Maximum length of 100 characters
            public string Title { get; set; }

            [Required] // Category is required
            [StringLength(100)] // Maximum length of 100 characters
            public string Category { get; set; }

            [Required] // ISBN is required
            public int ISBN { get; set; }
        }
    }
}



 